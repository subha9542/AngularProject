import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'foodorb-includes-main',
  templateUrl: './includes-main.component.html',
  styleUrls: ['./includes-main.component.scss']
})
export class IncludesMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
