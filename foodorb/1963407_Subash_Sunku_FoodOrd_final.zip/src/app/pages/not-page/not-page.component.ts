import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'foodorb-not-page',
  templateUrl: './not-page.component.html',
  styleUrls: ['./not-page.component.scss']
})
export class NotPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
