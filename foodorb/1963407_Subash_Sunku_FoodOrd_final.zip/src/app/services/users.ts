export interface Users {

  id: any,

  name: any,

  addresses: any,

  email: any


}

