export interface Items {
  id: number,

  name: string,

  product: string,

  desc: string,

  rating: number,

  price: number,

  imageUrl:string
}
